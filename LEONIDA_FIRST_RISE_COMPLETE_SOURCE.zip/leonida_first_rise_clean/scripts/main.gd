extends Node3D

# LEONIDA: FIRST RISE — prototype autonome Godot 4
const WALK_SPEED: float = 5.0
const RUN_SPEED: float = 8.0
const JUMP_VELOCITY: float = 5.5
const GRAVITY: float = 16.0

var player: CharacterBody3D
var camera: Camera3D
var car: CharacterBody3D
var npcs: Array[CharacterBody3D] = []
var package_marker: Node3D
var in_car: bool = false
var car_speed: float = 0.0
var camera_yaw: float = 0.0
var camera_pitch: float = -0.18
var look_touch_active: bool = false
var last_look_pos: Vector2 = Vector2.ZERO
var held: Dictionary = {"forward": false, "back": false, "left": false, "right": false, "sprint": false, "gas": false, "brake": false}
var mission_done: bool = false
var status_label: Label
var attack_cooldown: float = 0.0

func _ready() -> void:
	_build_world()
	_build_player()
	_build_vehicle()
	_build_npcs()
	_build_mission()
	_build_ui()
	_setup_input()
	_set_status("Bienvenue à Leonida. Trouve la voiture ou récupère le colis jaune.")

func _physics_process(delta: float) -> void:
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	_update_player(delta)
	_update_vehicle(delta)
	_update_npcs(delta)
	_update_camera()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x > get_viewport().size.x * 0.48:
			look_touch_active = true
			last_look_pos = event.position
		elif not event.pressed:
			look_touch_active = false
	elif event is InputEventScreenDrag and look_touch_active:
			var change: Vector2 = event.position - last_look_pos
			last_look_pos = event.position
			camera_yaw -= change.x * 0.006
			camera_pitch = clampf(camera_pitch - change.y * 0.004, -0.75, 0.25)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		camera_yaw -= event.relative.x * 0.005
		camera_pitch = clampf(camera_pitch - event.relative.y * 0.004, -0.75, 0.25)

func _build_world() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.15
	add_child(sun)
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.86)
	env.ambient_light_energy = 0.65
	world_env.environment = env
	add_child(world_env)
	_add_box("Ground", Vector3(0, -0.55, 0), Vector3(180, 1, 180), Color(0.24, 0.43, 0.27), true)
	_add_box("Main road", Vector3(0, -0.035, 0), Vector3(14, 0.08, 180), Color(0.12, 0.13, 0.15), false)
	_add_box("Cross road", Vector3(0, -0.025, 0), Vector3(180, 0.08, 12), Color(0.12, 0.13, 0.15), false)
	for z in range(-80, 81, 12):
		_add_box("Road marking", Vector3(0, 0.015, float(z)), Vector3(0.18, 0.025, 4), Color(0.95, 0.86, 0.55), false)
	for x in range(-75, 76, 18):
		for z in range(-75, 76, 22):
			if absf(float(x)) < 12.0 or absf(float(z)) < 10.0:
				continue
			var h: float = 5.0 + float(abs(x * 7 + z * 3) % 9)
			var w: float = 7.0 + float(abs(x + z) % 5)
			var colors: Array[Color] = [Color(0.72,0.62,0.49), Color(0.62,0.68,0.72), Color(0.78,0.73,0.61), Color(0.48,0.58,0.61)]
			_add_box("Building", Vector3(float(x), h * 0.5, float(z)), Vector3(w, h, 8), colors[abs(x + z) % 4], true)
	for i in range(28):
		var tx: float = float((i * 17) % 130 - 65)
		var tz: float = float((i * 29) % 130 - 65)
		if absf(tx) < 10.0 or absf(tz) < 8.0:
			continue
		_add_tree(Vector3(tx, 0, tz))

func _add_box(label_text: String, pos: Vector3, size: Vector3, color: Color, solid: bool) -> Node3D:
	var root: Node3D
	if solid:
		var body := StaticBody3D.new()
		root = body
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		collision.shape = shape
		body.add_child(collision)
	else:
		root = Node3D.new()
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh_instance.material_override = mat
	root.add_child(mesh_instance)
	root.position = pos
	root.name = label_text
	add_child(root)
	return root

func _add_tree(pos: Vector3) -> void:
	_add_box("Tree trunk", pos + Vector3(0, 1.0, 0), Vector3(0.45, 2, 0.45), Color(0.30, 0.18, 0.10), false)
	var crown := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 1.35
	sphere.height = 2.7
	crown.mesh = sphere
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.12, 0.36, 0.17)
	crown.material_override = mat
	crown.position = pos + Vector3(0, 2.6, 0)
	add_child(crown)

func _add_capsule_visual(parent: Node3D, pos: Vector3, radius: float, height: float, color: Color) -> void:
	var m := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	m.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	m.material_override = mat
	m.position = pos
	parent.add_child(m)

func _add_sphere_visual(parent: Node3D, pos: Vector3, radius: float, color: Color) -> void:
	var m := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	m.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	m.material_override = mat
	m.position = pos
	parent.add_child(m)

func _add_box_visual(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
	var m := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	m.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	m.material_override = mat
	m.position = pos
	parent.add_child(m)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 0.05, 4)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	collision.shape = capsule
	collision.position.y = 0.9
	player.add_child(collision)
	var visual := Node3D.new()
	visual.name = "Visual"
	player.add_child(visual)
	_add_capsule_visual(visual, Vector3(0, 1.0, 0), 0.42, 1.0, Color(0.12, 0.24, 0.68))
	_add_sphere_visual(visual, Vector3(0, 1.82, 0), 0.28, Color(0.72, 0.48, 0.34))
	_add_box_visual(visual, Vector3(-0.22, 0.48, 0), Vector3(0.18, 0.72, 0.22), Color(0.08,0.09,0.12))
	_add_box_visual(visual, Vector3(0.22, 0.48, 0), Vector3(0.18, 0.72, 0.22), Color(0.08,0.09,0.12))
	add_child(player)
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position = Vector3(0, 1.65, 0)
	player.add_child(pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 1.0, 5.5)
	camera.rotation.x = -0.12
	camera.current = true
	pivot.add_child(camera)

func _build_vehicle() -> void:
	car = CharacterBody3D.new()
	car.name = "Leonida Sports Car"
	car.position = Vector3(4.0, 0.45, 2.0)
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.0, 0.8, 3.8)
	col.shape = box
	car.add_child(col)
	var visual := Node3D.new()
	car.add_child(visual)
	_add_box_visual(visual, Vector3(0, 0.0, 0), Vector3(2.0, 0.65, 3.8), Color(0.78, 0.08, 0.06))
	_add_box_visual(visual, Vector3(0, 0.48, -0.25), Vector3(1.55, 0.65, 1.8), Color(0.16, 0.24, 0.30))
	for wx in [-0.92, 0.92]:
		for wz in [-1.25, 1.25]:
			_add_sphere_visual(visual, Vector3(wx, -0.25, wz), 0.38, Color(0.035,0.035,0.04))
	add_child(car)

func _build_npcs() -> void:
	var positions: Array[Vector3] = [Vector3(-5, 0.05, 2), Vector3(7, 0.05, -5), Vector3(-8, 0.05, -8), Vector3(3, 0.05, 11)]
	for i in range(positions.size()):
		var npc := CharacterBody3D.new()
		npc.name = "Resident_%d" % (i + 1)
		npc.position = positions[i]
		var col := CollisionShape3D.new()
		var shape := CapsuleShape3D.new()
		shape.radius = 0.35
		shape.height = 1.65
		col.shape = shape
		col.position.y = 0.82
		npc.add_child(col)
		var visual := Node3D.new()
		_add_capsule_visual(visual, Vector3(0, 0.85, 0), 0.35, 0.95, Color(0.18 + float(i) * 0.12, 0.42, 0.30 + float(i) * 0.08))
		_add_sphere_visual(visual, Vector3(0, 1.58, 0), 0.23, Color(0.65, 0.43, 0.30))
		npc.add_child(visual)
		npc.set_meta("health", 100)
		npc.set_meta("hostile", false)
		add_child(npc)
		npcs.append(npc)

func _build_mission() -> void:
	package_marker = Node3D.new()
	package_marker.position = Vector3(-10, 0.05, -3)
	var marker := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.65
	mesh.bottom_radius = 0.65
	mesh.height = 0.12
	marker.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.78, 0.05)
	mat.emission_enabled = true
	mat.emission = Color(0.45, 0.25, 0.0)
	marker.material_override = mat
	package_marker.add_child(marker)
	add_child(package_marker)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	layer.add_child(root)
	status_label = Label.new()
	status_label.position = Vector2(18, 14)
	status_label.size = Vector2(700, 48)
	status_label.add_theme_font_size_override("font_size", 22)
	status_label.add_theme_color_override("font_color", Color.WHITE)
	status_label.add_theme_color_override("font_shadow_color", Color.BLACK)
	status_label.add_theme_constant_override("shadow_offset_x", 2)
	status_label.add_theme_constant_override("shadow_offset_y", 2)
	root.add_child(status_label)
	_add_hold_button(root, "↑", Vector2(80, -180), "forward", Vector2(58, 58))
	_add_hold_button(root, "↓", Vector2(80, -80), "back", Vector2(58, 58))
	_add_hold_button(root, "←", Vector2(20, -130), "left", Vector2(58, 58))
	_add_hold_button(root, "→", Vector2(140, -130), "right", Vector2(58, 58))
	_add_hold_button(root, "SPRINT", Vector2(215, -100), "sprint", Vector2(105, 58))
	_add_action_button(root, "SAUT", Vector2(-270, -190), Callable(self, "_jump"))
	_add_action_button(root, "ATTAQUE", Vector2(-270, -120), Callable(self, "_attack"))
	_add_action_button(root, "ACTION", Vector2(-270, -50), Callable(self, "_interact"))
	_add_hold_button(root, "GAZ", Vector2(-130, -190), "gas", Vector2(90, 58))
	_add_hold_button(root, "FREIN", Vector2(-130, -120), "brake", Vector2(90, 58))

func _add_hold_button(root: Control, caption: String, offset: Vector2, key_name: String, button_size: Vector2) -> void:
	var button := Button.new()
	button.text = caption
	button.anchor_left = 0.0 if offset.x >= 0.0 else 1.0
	button.anchor_right = button.anchor_left
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = offset.x
	button.offset_right = offset.x + button_size.x
	button.offset_top = offset.y
	button.offset_bottom = offset.y + button_size.y
	button.add_theme_font_size_override("font_size", 16)
	root.add_child(button)
	button.button_down.connect(func(): held[key_name] = true)
	button.button_up.connect(func(): held[key_name] = false)

func _add_action_button(root: Control, caption: String, offset: Vector2, action: Callable) -> void:
	var button := Button.new()
	button.text = caption
	button.anchor_left = 1.0
	button.anchor_right = 1.0
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = offset.x
	button.offset_right = offset.x + 112.0
	button.offset_top = offset.y
	button.offset_bottom = offset.y + 58.0
	button.add_theme_font_size_override("font_size", 16)
	root.add_child(button)
	button.pressed.connect(action)

func _setup_input() -> void:
	_add_key("move_forward", KEY_W)
	_add_key("move_forward", KEY_UP)
	_add_key("move_back", KEY_S)
	_add_key("move_back", KEY_DOWN)
	_add_key("move_left", KEY_A)
	_add_key("move_left", KEY_LEFT)
	_add_key("move_right", KEY_D)
	_add_key("move_right", KEY_RIGHT)
	_add_key("sprint", KEY_SHIFT)
	_add_key("jump", KEY_SPACE)
	_add_key("attack", KEY_F)
	_add_key("interact", KEY_E)

func _add_key(action_name: String, keycode: Key) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	InputMap.action_add_event(action_name, event)

func _update_player(delta: float) -> void:
	if in_car:
		player.velocity = Vector3.ZERO
		player.global_position = car.global_position + Vector3(0, 0.2, 0)
		return
	var direction := Vector3.ZERO
	if held["forward"] or Input.is_action_pressed("move_forward"):
		direction.z -= 1.0
	if held["back"] or Input.is_action_pressed("move_back"):
		direction.z += 1.0
	if held["left"] or Input.is_action_pressed("move_left"):
		direction.x -= 1.0
	if held["right"] or Input.is_action_pressed("move_right"):
		direction.x += 1.0
	direction = direction.normalized()
	var world_direction: Vector3 = Basis(Vector3.UP, camera_yaw) * direction
	var speed: float = RUN_SPEED if held["sprint"] or Input.is_action_pressed("sprint") else WALK_SPEED
	player.velocity.x = world_direction.x * speed
	player.velocity.z = world_direction.z * speed
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif Input.is_action_just_pressed("jump"):
		player.velocity.y = JUMP_VELOCITY
	player.move_and_slide()
	if world_direction.length() > 0.1:
		player.rotation.y = atan2(-world_direction.x, -world_direction.z)
	if Input.is_action_just_pressed("attack"):
		_attack()
	if Input.is_action_just_pressed("interact"):
		_interact()

func _update_vehicle(delta: float) -> void:
	if not in_car:
		return
	var throttle: float = 0.0
	if held["gas"] or held["forward"]:
		throttle += 1.0
	if held["brake"] or held["back"]:
		throttle -= 1.0
	car_speed = move_toward(car_speed, throttle * 17.0, 12.0 * delta)
	var steering: float = 0.0
	if held["left"]:
		steering -= 1.0
	if held["right"]:
		steering += 1.0
	car.rotation.y += steering * delta * clampf(absf(car_speed) / 8.0, 0.15, 1.0) * 1.5
	car.velocity = -car.global_transform.basis.z * car_speed
	car.move_and_slide()
	player.global_position = car.global_position + Vector3(0, 0.2, 0)
	player.rotation.y = car.rotation.y

func _update_npcs(delta: float) -> void:
	for npc in npcs:
		if not is_instance_valid(npc):
			continue
		var hostile: bool = bool(npc.get_meta("hostile", false))
		if hostile and not in_car:
			var to_player: Vector3 = player.global_position - npc.global_position
			to_player.y = 0.0
			if to_player.length() > 1.3:
				npc.velocity = to_player.normalized() * 2.2
				npc.rotation.y = atan2(-to_player.x, -to_player.z)
			else:
				npc.velocity = Vector3.ZERO
		else:
			npc.velocity = Vector3.ZERO
		npc.velocity.y -= GRAVITY * delta
		npc.move_and_slide()

func _update_camera() -> void:
	if not is_instance_valid(camera):
		return
	var pivot := player.get_node_or_null("CameraPivot") as Node3D
	if pivot != null:
		pivot.rotation.y = camera_yaw
		pivot.rotation.x = camera_pitch

func _jump() -> void:
	if not in_car and player.is_on_floor():
		player.velocity.y = JUMP_VELOCITY

func _attack() -> void:
	if in_car or attack_cooldown > 0.0:
		return
	attack_cooldown = 0.55
	var nearest: CharacterBody3D = null
	var nearest_distance: float = 2.8
	for npc in npcs:
		var distance: float = player.global_position.distance_to(npc.global_position)
		if distance < nearest_distance:
			nearest = npc
			nearest_distance = distance
	if nearest != null:
		var hp: int = int(nearest.get_meta("health", 100)) - 35
		nearest.set_meta("health", hp)
		nearest.set_meta("hostile", true)
		_set_status("Coup porté ! Santé du PNJ : %d" % maxi(0, hp))
		if hp <= 0:
			npcs.erase(nearest)
			nearest.queue_free()
			_set_status("PNJ neutralisé.")
	else:
		_set_status("Aucun PNJ à portée.")

func _interact() -> void:
	if in_car:
		in_car = false
		player.visible = true
		player.collision_layer = 1
		player.collision_mask = 1
		player.global_position = car.global_position + car.global_transform.basis.x * 2.0 + Vector3(0, 0.6, 0)
		car_speed = 0.0
		_set_status("Tu es sorti du véhicule.")
		return
	if player.global_position.distance_to(car.global_position) < 4.0:
		in_car = true
		player.visible = false
		player.collision_layer = 0
		player.collision_mask = 0
		_set_status("Véhicule pris. Utilise GAZ, FREIN et les flèches.")
		return
	if not mission_done and player.global_position.distance_to(package_marker.global_position) < 2.2:
		mission_done = true
		package_marker.visible = false
		_set_status("Mission terminée : colis récupéré !")
		return
	var closest: float = 999.0
	for npc in npcs:
		closest = minf(closest, player.global_position.distance_to(npc.global_position))
	if closest < 2.5:
		_set_status("Le résident te salue. Explore la ville !")
	else:
		_set_status("Approche-toi de la voiture ou du marqueur jaune.")

func _set_status(message: String) -> void:
	if is_instance_valid(status_label):
		status_label.text = message
