# LEONIDA: FIRST RISE

Starter project for Godot 4.3+ using the Compatibility renderer. The prototype generates its world and gameplay from one GDScript file; no imported art assets or external plugins are required.

## Open
1. Install Godot 4.3 or newer.
2. Import `project.godot` from this folder.
3. Press Play.

## Controls
- Desktop: WASD/arrows move, Shift sprint, Space jump, F attack, E interact.
- Touch: directional buttons, SPRINT, SAUT, ATTAQUE, ACTION, GAZ and FREIN.
- Drag the right half of the screen to rotate the camera.

## Included
- Procedural low-poly city block, roads, buildings and trees.
- Third-person player and follow camera.
- Basic drivable car; approach and press ACTION to enter/exit.
- Four NPCs; attack damages nearby NPCs and makes them chase.
- Package pickup mission.

## Limits
This is a prototype built with primitive geometry. It does not yet include realistic rigged characters, motion capture, advanced vehicle physics, sound, save/load, a large streaming open world, police AI, weapon systems or a full campaign. It has not been runtime-tested in Godot in this environment. Test in the Godot editor before publishing.

## GitHub
Upload the contents of this folder to a new repository. Do not upload `.godot/` cache folders if Godot creates them.
